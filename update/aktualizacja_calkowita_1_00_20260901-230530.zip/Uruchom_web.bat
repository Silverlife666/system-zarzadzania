@echo off
chcp 65001 >nul
set "APP_PYTHON=C:\Users\Adrian\AppData\Local\Programs\Python\Python314\python.exe"

echo ==========================================
echo Instalacja/Sprawdzanie wymaganych pakietow...
echo ==========================================
"%APP_PYTHON%" -m pip install --upgrade pip
"%APP_PYTHON%" -m pip install streamlit pandas numpy matplotlib plotly reportlab odfpy openpyxl opencv-python

echo.
echo ==========================================
echo Uruchamianie aplikacji Streamlit...
echo ==========================================
wscript.exe "%~dp0start.vbs"
