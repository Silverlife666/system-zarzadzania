Set WshShell = CreateObject("WScript.Shell")

WshShell.CurrentDirectory = "C:\Users\Adrian\Desktop\System_beta"
WshShell.Run """C:\Users\Adrian\AppData\Local\Programs\Python\Python314\python.exe"" -m streamlit run app.py", 0, False
