"""Narzędzia do generowania kodów, etykiet i numerów partii."""
from __future__ import annotations

from datetime import datetime
from io import BytesIO

from reportlab.graphics import renderPDF, renderSVG
from reportlab.graphics.barcode import createBarcodeDrawing
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas


def _ean13_value(value: str) -> str:
    digits = "".join(character for character in value if character.isdigit())
    if len(digits) == 12:
        return digits
    if len(digits) == 13:
        weights = (1, 3) * 6
        check = (10 - sum(int(item) * weight for item, weight in zip(digits[:12], weights)) % 10) % 10
        if check != int(digits[-1]):
            raise ValueError("Podany EAN-13 ma nieprawidłową cyfrę kontrolną.")
        return digits[:12]
    raise ValueError("EAN wymaga 12 cyfr (cyfra kontrolna zostanie dodana) lub prawidłowych 13 cyfr.")


def _drawing(code_type: str, value: str) -> Drawing:
    if code_type == "EAN-13":
        return createBarcodeDrawing("EAN13", value=_ean13_value(value), barHeight=52, humanReadable=True)
    if code_type == "Code 128":
        return createBarcodeDrawing("Code128", value=value, barHeight=52, barWidth=1.05, humanReadable=True)
    widget = QrCodeWidget(value)
    x1, y1, x2, y2 = widget.getBounds()
    size = 58
    drawing = Drawing(size, size, transform=[size / (x2 - x1), 0, 0, size / (y2 - y1), 0, 0])
    drawing.add(widget)
    return drawing


def _code_svg(code_type: str, value: str) -> str:
    return renderSVG.drawToString(_drawing(code_type, value))


def _label_pdf(code_type: str, value: str, title: str, description: str) -> bytes:
    buffer = BytesIO()
    width, height = 100 * mm, 65 * mm
    pdf = canvas.Canvas(buffer, pagesize=(width, height))
    pdf.setStrokeColorRGB(0.2, 0.2, 0.25)
    pdf.roundRect(3 * mm, 3 * mm, width - 6 * mm, height - 6 * mm, 2 * mm)
    pdf.setFont("Helvetica-Bold", 11)
    pdf.drawString(8 * mm, height - 12 * mm, (title or "ETYKIETA")[:48])
    pdf.setFont("Helvetica", 8)
    pdf.drawString(8 * mm, height - 18 * mm, (description or "")[:72])
    drawing = _drawing(code_type, value)
    scale = min((width - 16 * mm) / drawing.width, 32 * mm / drawing.height)
    pdf.saveState()
    pdf.translate(8 * mm, 11 * mm)
    pdf.scale(scale, scale)
    renderPDF.draw(drawing, pdf, 0, 0)
    pdf.restoreState()
    pdf.setFont("Helvetica", 7)
    pdf.drawRightString(width - 8 * mm, 7 * mm, f"{code_type}: {value}")
    pdf.showPage()
    pdf.save()
    return buffer.getvalue()


def render_generators_screen(st, deps: dict) -> None:
    st.title("🧰 Generatory")
    code_tab, label_tab, batch_tab = st.tabs(["▥ Kody", "🏷️ Etykiety", "# Numery partii"])

    with code_tab:
        st.subheader("Generator kodów")
        code_type = st.selectbox("Rodzaj kodu", ["Code 128", "EAN-13", "QR"], key="generator_code_type")
        placeholder = "np. SKU lub numer zlecenia" if code_type == "Code 128" else ("12 lub 13 cyfr" if code_type == "EAN-13" else "tekst, link lub numer zlecenia")
        value = st.text_input("Zawartość kodu", placeholder=placeholder, key="generator_code_value")
        if value.strip():
            try:
                svg = _code_svg(code_type, value.strip())
                st.components.v1.html(svg, height=145, scrolling=False)
                st.download_button("⬇️ Pobierz kod SVG", svg.encode("utf-8"), file_name=f"kod_{code_type}_{value.strip()}.svg", mime="image/svg+xml")
            except Exception as error:
                st.error(f"Nie można wygenerować kodu: {error}")
        else:
            st.caption("Dostępne typy: Code 128, EAN-13 i QR.")

    with label_tab:
        st.subheader("Generator etykiety PDF")
        left, right = st.columns(2)
        with left:
            label_type = st.selectbox("Rodzaj kodu na etykiecie", ["Code 128", "EAN-13", "QR"], key="label_code_type")
            label_value = st.text_input("Zawartość kodu", key="label_code_value")
        with right:
            label_title = st.text_input("Tytuł etykiety", value="ETYKIETA PRODUKTU", key="label_title")
            label_description = st.text_input("Opis", placeholder="np. nazwa produktu / klient", key="label_description")
        if label_value.strip():
            try:
                label = _label_pdf(label_type, label_value.strip(), label_title, label_description)
                st.download_button("⬇️ Pobierz etykietę PDF", label, file_name="etykieta.pdf", mime="application/pdf", type="primary")
            except Exception as error:
                st.error(f"Nie można wygenerować etykiety: {error}")
        else:
            st.caption("Wpisz zawartość kodu, aby przygotować etykietę do pobrania.")

    with batch_tab:
        st.subheader("Generator numerów partii")
        left, middle, right = st.columns(3)
        with left:
            prefix = st.text_input("Prefiks", value="PARTIA", key="batch_prefix")
        with middle:
            sequence = st.number_input("Numer kolejny", min_value=1, value=1, step=1, key="batch_sequence")
        with right:
            include_date = st.checkbox("Dodaj datę", value=True, key="batch_include_date")
        date_part = datetime.now().strftime("%Y%m%d") if include_date else ""
        number = "-".join(part for part in [prefix.strip().upper(), date_part, f"{int(sequence):04d}"] if part)
        st.code(number)
        if st.button("➕ Zapisz numer partii", key="save_generated_batch"):
            database = deps["load_database"]()
            records = database.get("generated_batch_numbers", [])
            records.insert(0, {"number": number, "created_at": datetime.now().isoformat(timespec="seconds")})
            database["generated_batch_numbers"] = records[:500]
            deps["save_database"](database)
            st.success("Numer partii zapisany.")
        records = deps["load_database"]().get("generated_batch_numbers", [])
        if records:
            st.caption("Ostatnio wygenerowane numery")
            st.dataframe(records[:20], use_container_width=True, hide_index=True)
